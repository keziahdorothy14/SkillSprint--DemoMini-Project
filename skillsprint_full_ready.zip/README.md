# SkillSprint Full Project

Follow client/README.md and functions/README.md to configure and deploy.
