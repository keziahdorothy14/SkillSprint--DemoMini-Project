#!/usr/bin/env bash
mvn clean package
java -jar target/skillsprint-2.0.0.jar
