package com.skillsprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillSprintApplicationTests {
    @Test
    void contextLoads() { }
}
